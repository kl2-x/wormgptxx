import express from 'express';
import cors from 'cors';
import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import os from 'os';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import multer from 'multer';
import AdmZip from 'adm-zip';
import { fileURLToPath } from 'url';
import simpleGit from 'simple-git';

const execAsync = promisify(exec);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ server: httpServer });

// ── CORS ──────────────────────────────────────────────────────────────────────
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.options('*', cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024 } });

// ── Backend State ─────────────────────────────────────────────────────────────
//
//  backendMode options:
//    'ollama'      - Remote Ollama on another PC/VPS (x86 not needed on phone)
//    'llamacpp'    - llama.cpp server running in Termux (ARM-native)
//    'groq'        - Groq cloud API (free tier, very fast)
//    'openrouter'  - OpenRouter cloud API (free models available)
//    'openai'      - OpenAI API
//    'anthropic'   - Anthropic Claude API
//
let backendMode   = process.env.BACKEND_MODE   || 'ollama';
let ollamaBaseUrl = process.env.OLLAMA_URL     || 'http://localhost:11434';
let llamaCppUrl   = process.env.LLAMACPP_URL   || 'http://localhost:8080';
let groqApiKey    = process.env.GROQ_API_KEY   || '';
let openrouterKey = process.env.OPENROUTER_KEY || '';
let openaiKey     = process.env.OPENAI_API_KEY || '';
let anthropicKey  = process.env.ANTHROPIC_KEY  || '';
let defaultModel  = process.env.DEFAULT_MODEL  || '';

let ollamaHealthy = false;

// ── Ollama Health Check ───────────────────────────────────────────────────────
const checkOllamaHealth = async (base = ollamaBaseUrl) => {
  try {
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 3000);
    const r = await fetch(`${base}/api/tags`, { signal: ctrl.signal });
    clearTimeout(timeout);
    ollamaHealthy = r.ok;
    return r.ok;
  } catch {
    ollamaHealthy = false;
    return false;
  }
};
setInterval(() => { if (backendMode === 'ollama') checkOllamaHealth(); }, 10000);
checkOllamaHealth();

// ── WebSocket: Terminal & Code Runner ─────────────────────────────────────────
wss.on('connection', (ws) => {
  let proc = null;

  const safeSend = (data) => {
    if (ws.readyState === ws.OPEN) {
      try { ws.send(JSON.stringify(data)); } catch {}
    }
  };

  ws.on('message', (raw) => {
    try {
      const { type, code, lang, command, cwd } = JSON.parse(raw.toString());

      if (type === 'run_code') {
        const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wgpt-'));
        let filename, runCmd;

        if (lang === 'python' || lang === 'py') {
          filename = path.join(tmpDir, 'main.py');
          fs.writeFileSync(filename, code);
          runCmd = `python3 "${filename}"`;
        } else if (lang === 'javascript' || lang === 'js') {
          filename = path.join(tmpDir, 'main.js');
          fs.writeFileSync(filename, code);
          runCmd = `node "${filename}"`;
        } else if (lang === 'bash' || lang === 'sh') {
          filename = path.join(tmpDir, 'main.sh');
          fs.writeFileSync(filename, code);
          runCmd = `bash "${filename}"`;
        } else {
          safeSend({ type: 'stderr', data: 'Unsupported language: ' + lang });
          safeSend({ type: 'exit', code: 1 });
          return;
        }

        safeSend({ type: 'start' });
        proc = spawn('sh', ['-c', runCmd], { cwd: tmpDir });
        proc.stdout.on('data', d => safeSend({ type: 'stdout', data: d.toString() }));
        proc.stderr.on('data', d => safeSend({ type: 'stderr', data: d.toString() }));
        proc.on('close', code => {
          safeSend({ type: 'exit', code });
          proc = null;
          try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
        });
        proc.on('error', (err) => {
          safeSend({ type: 'stderr', data: `Process error: ${err.message}` });
          safeSend({ type: 'exit', code: 1 });
          proc = null;
        });

      } else if (type === 'kill') {
        if (proc) { proc.kill('SIGTERM'); proc = null; }

      } else if (type === 'shell') {
        const workDir = cwd || os.homedir();
        proc = spawn('sh', ['-c', command], {
          cwd: fs.existsSync(workDir) ? workDir : os.homedir(),
          env: process.env,
        });
        proc.stdout.on('data', d => safeSend({ type: 'stdout', data: d.toString() }));
        proc.stderr.on('data', d => safeSend({ type: 'stderr', data: d.toString() }));
        proc.on('close', code => { safeSend({ type: 'exit', code }); proc = null; });
        proc.on('error', (err) => {
          safeSend({ type: 'stderr', data: `Shell error: ${err.message}` });
          proc = null;
        });
      }
    } catch (e) {
      safeSend({ type: 'stderr', data: `Parse error: ${e.message}` });
    }
  });

  ws.on('close', () => { if (proc) { try { proc.kill(); } catch {} proc = null; } });
  ws.on('error', () => { if (proc) { try { proc.kill(); } catch {} proc = null; } });
});

// ── Backend Config API ────────────────────────────────────────────────────────
app.post('/api/backend/config', (req, res) => {
  const { mode, ollamaUrl, llamacppUrl, groqKey, openrouterApiKey, openaiApiKey, anthropicApiKey, model } = req.body;
  if (mode)             backendMode   = mode;
  if (ollamaUrl)        ollamaBaseUrl = ollamaUrl;
  if (llamacppUrl)      llamaCppUrl   = llamacppUrl;
  if (groqKey)          groqApiKey    = groqKey;
  if (openrouterApiKey) openrouterKey = openrouterApiKey;
  if (openaiApiKey)     openaiKey     = openaiApiKey;
  if (anthropicApiKey)  anthropicKey  = anthropicApiKey;
  if (model)            defaultModel  = model;
  res.json({ ok: true, mode: backendMode });
});

app.get('/api/backend/config', (req, res) => {
  res.json({
    mode: backendMode,
    ollamaUrl: ollamaBaseUrl,
    llamacppUrl: llamaCppUrl,
    hasGroqKey: !!groqApiKey,
    hasOpenrouterKey: !!openrouterKey,
    hasOpenaiKey: !!openaiKey,
    hasAnthropicKey: !!anthropicKey,
    defaultModel,
  });
});

// ── Model Lists ───────────────────────────────────────────────────────────────
const GROQ_MODELS = [
  'llama-3.3-70b-versatile',
  'llama-3.1-8b-instant',
  'llama3-70b-8192',
  'llama3-8b-8192',
  'mixtral-8x7b-32768',
  'gemma2-9b-it',
  'deepseek-r1-distill-llama-70b',
];

const OPENROUTER_FREE_MODELS = [
  'meta-llama/llama-3.1-8b-instruct:free',
  'meta-llama/llama-3.2-3b-instruct:free',
  'microsoft/phi-3-mini-128k-instruct:free',
  'mistralai/mistral-7b-instruct:free',
  'google/gemma-2-9b-it:free',
  'qwen/qwen-2-7b-instruct:free',
  'nousresearch/hermes-3-llama-3.1-405b:free',
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function setupSSE(res) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
}

// ── Unified Chat API ──────────────────────────────────────────────────────────
app.post('/api/chat', async (req, res) => {
  const { messages, model, temperature, stream, ollamaUrl, backendConfig } = req.body;

  // Per-request overrides
  if (backendConfig) {
    if (backendConfig.mode)          backendMode   = backendConfig.mode;
    if (backendConfig.ollamaUrl)     ollamaBaseUrl = backendConfig.ollamaUrl;
    if (backendConfig.llamacppUrl)   llamaCppUrl   = backendConfig.llamacppUrl;
    if (backendConfig.groqKey)       groqApiKey    = backendConfig.groqKey;
    if (backendConfig.openrouterKey) openrouterKey = backendConfig.openrouterKey;
    if (backendConfig.openaiKey)     openaiKey     = backendConfig.openaiKey;
    if (backendConfig.anthropicKey)  anthropicKey  = backendConfig.anthropicKey;
  }
  if (ollamaUrl) ollamaBaseUrl = ollamaUrl;

  const mode = backendMode;
  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(), 180000);

  try {
    if (mode === 'ollama') {
      await handleOllama({ messages, model, temperature, stream, res, ctrl, timeout, req });
    } else if (mode === 'llamacpp') {
      await handleOpenAICompat({
        messages, model: model || defaultModel || 'local', temperature, stream, res, ctrl, timeout,
        baseUrl: llamaCppUrl, apiKey: 'no-key', provider: 'llama.cpp',
      });
    } else if (mode === 'groq') {
      await handleOpenAICompat({
        messages, model: model || defaultModel || GROQ_MODELS[0], temperature, stream, res, ctrl, timeout,
        baseUrl: 'https://api.groq.com/openai/v1', apiKey: groqApiKey, provider: 'Groq',
      });
    } else if (mode === 'openrouter') {
      await handleOpenAICompat({
        messages, model: model || defaultModel || OPENROUTER_FREE_MODELS[0], temperature, stream, res, ctrl, timeout,
        baseUrl: 'https://openrouter.ai/api/v1', apiKey: openrouterKey, provider: 'OpenRouter',
        extraHeaders: { 'HTTP-Referer': 'http://localhost:3001', 'X-Title': 'WormGPT' },
      });
    } else if (mode === 'openai') {
      await handleOpenAICompat({
        messages, model: model || defaultModel || 'gpt-4o-mini', temperature, stream, res, ctrl, timeout,
        baseUrl: 'https://api.openai.com/v1', apiKey: openaiKey, provider: 'OpenAI',
      });
    } else if (mode === 'anthropic') {
      await handleAnthropic({ messages, model, temperature, stream, res, ctrl, timeout });
    } else {
      clearTimeout(timeout);
      res.status(400).json({ error: `Unknown backend mode: ${mode}` });
    }
  } catch (e) {
    clearTimeout(timeout);
    if (e.name === 'AbortError') {
      res.status(408).json({ error: 'Request timeout — model may be loading, try again' });
    } else {
      res.status(500).json({ error: e.message });
    }
  }
});

// ── Ollama Handler ────────────────────────────────────────────────────────────
async function handleOllama({ messages, model, temperature, stream, res, ctrl, timeout, req }) {
  const resp = await fetch(`${ollamaBaseUrl}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: model || defaultModel || 'godmoded/llama3-lexi-uncensored',
      messages,
      temperature: temperature ?? 0.7,
      stream: stream !== false,
    }),
    signal: ctrl.signal,
  });

  clearTimeout(timeout);
  if (!resp.ok) { const t = await resp.text(); res.status(resp.status).json({ error: t }); return; }

  if (stream !== false) {
    setupSSE(res);
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    req?.on('close', () => { try { reader.cancel(); } catch {} });
    while (true) {
      const { done, value } = await reader.read();
      if (done) { res.write('data: [DONE]\n\n'); res.end(); break; }
      const text = decoder.decode(value);
      for (const line of text.split('\n').filter(l => l.trim())) {
        try {
          const json = JSON.parse(line);
          res.write(`data: ${JSON.stringify(json)}\n\n`);
          if (json.done) { res.end(); return; }
        } catch {}
      }
    }
  } else {
    res.json(await resp.json());
  }
}

// ── OpenAI-Compatible Handler (Groq, OpenRouter, OpenAI, llama.cpp) ───────────
async function handleOpenAICompat({ messages, model, temperature, stream, res, ctrl, timeout, baseUrl, apiKey, provider, extraHeaders = {} }) {
  const needsKey = provider !== 'llama.cpp';
  if (needsKey && !apiKey) {
    clearTimeout(timeout);
    res.status(401).json({ error: `${provider} API key not set. Open Settings → Backend → enter your ${provider} API key.` });
    return;
  }

  const resp = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      ...extraHeaders,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: temperature ?? 0.7,
      stream: stream !== false,
    }),
    signal: ctrl.signal,
  });

  clearTimeout(timeout);
  if (!resp.ok) {
    const errText = await resp.text();
    res.status(resp.status).json({ error: `${provider} error: ${errText}` });
    return;
  }

  if (stream !== false) {
    setupSSE(res);
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) { res.write('data: [DONE]\n\n'); res.end(); break; }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const data = trimmed.slice(5).trim();
        if (data === '[DONE]') { res.write('data: [DONE]\n\n'); res.end(); return; }
        try {
          const json = JSON.parse(data);
          // Normalize to Ollama-style format so existing frontend code works unchanged
          const delta = json.choices?.[0]?.delta?.content || '';
          const finishReason = json.choices?.[0]?.finish_reason;
          const normalized = {
            message: { role: 'assistant', content: delta },
            done: finishReason === 'stop' || finishReason === 'length',
          };
          res.write(`data: ${JSON.stringify(normalized)}\n\n`);
          if (normalized.done) { res.end(); return; }
        } catch {}
      }
    }
  } else {
    const data = await resp.json();
    const content = data.choices?.[0]?.message?.content || '';
    res.json({ message: { role: 'assistant', content }, done: true });
  }
}

// ── Anthropic Handler ─────────────────────────────────────────────────────────
async function handleAnthropic({ messages, model, temperature, stream, res, ctrl, timeout }) {
  if (!anthropicKey) {
    clearTimeout(timeout);
    res.status(401).json({ error: 'Anthropic API key not set. Open Settings → Backend → enter your Anthropic API key.' });
    return;
  }

  const systemMsg = messages.find(m => m.role === 'system');
  const userMessages = messages.filter(m => m.role !== 'system');

  const body = {
    model: model || defaultModel || 'claude-haiku-4-5-20251001',
    max_tokens: 4096,
    temperature: temperature ?? 0.7,
    messages: userMessages,
    stream: stream !== false,
  };
  if (systemMsg) body.system = systemMsg.content;

  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': anthropicKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(body),
    signal: ctrl.signal,
  });

  clearTimeout(timeout);
  if (!resp.ok) { const t = await resp.text(); res.status(resp.status).json({ error: `Anthropic: ${t}` }); return; }

  if (stream !== false) {
    setupSSE(res);
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) { res.write('data: [DONE]\n\n'); res.end(); break; }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        try {
          const json = JSON.parse(trimmed.slice(5).trim());
          if (json.type === 'content_block_delta' && json.delta?.text) {
            res.write(`data: ${JSON.stringify({ message: { role: 'assistant', content: json.delta.text }, done: false })}\n\n`);
          } else if (json.type === 'message_stop') {
            res.write(`data: ${JSON.stringify({ message: { role: 'assistant', content: '' }, done: true })}\n\n`);
            res.end(); return;
          }
        } catch {}
      }
    }
  } else {
    const data = await resp.json();
    const content = data.content?.[0]?.text || '';
    res.json({ message: { role: 'assistant', content }, done: true });
  }
}

// ── Ollama Status ─────────────────────────────────────────────────────────────
app.get('/api/ollama/status', async (req, res) => {
  const base = req.query.url || ollamaBaseUrl;
  const connected = await checkOllamaHealth(base);
  res.json({ connected, url: base, mode: backendMode });
});

// ── Ollama Models ─────────────────────────────────────────────────────────────
app.get('/api/ollama/models', async (req, res) => {
  const base = req.query.url || ollamaBaseUrl;
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 5000);
    const r = await fetch(`${base}/api/tags`, { signal: ctrl.signal });
    if (!r.ok) throw new Error(`Ollama returned ${r.status}`);
    const data = await r.json();
    res.json(data);
  } catch (e) {
    res.status(503).json({ error: `Cannot reach Ollama at ${base}: ${e.message}` });
  }
});

// ── Ollama Pull ───────────────────────────────────────────────────────────────
app.post('/api/ollama/pull', async (req, res) => {
  const { model, ollamaUrl } = req.body;
  const base = ollamaUrl || ollamaBaseUrl;
  if (!model) { res.status(400).json({ error: 'model required' }); return; }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  try {
    const resp = await fetch(`${base}/api/pull`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: model, stream: true }),
    });
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) { res.write('data: [DONE]\n\n'); res.end(); break; }
      const text = decoder.decode(value);
      for (const line of text.split('\n').filter(l => l.trim())) {
        try { res.write(`data: ${line}\n\n`); } catch {}
      }
    }
  } catch (e) {
    res.write(`data: ${JSON.stringify({ error: e.message })}\n\n`);
    res.end();
  }
});

// ── Available Models (for Settings UI) ───────────────────────────────────────
app.get('/api/models', async (req, res) => {
  const mode = req.query.mode || backendMode;
  if (mode === 'groq') {
    res.json({ models: GROQ_MODELS.map(id => ({ id, name: id, provider: 'groq' })) });
  } else if (mode === 'openrouter') {
    res.json({ models: OPENROUTER_FREE_MODELS.map(id => ({ id, name: id, provider: 'openrouter' })) });
  } else if (mode === 'llamacpp') {
    res.json({ models: [{ id: 'local', name: 'llama.cpp local model', provider: 'llamacpp' }] });
  } else if (mode === 'ollama') {
    try {
      const ctrl = new AbortController();
      setTimeout(() => ctrl.abort(), 5000);
      const r = await fetch(`${ollamaBaseUrl}/api/tags`, { signal: ctrl.signal });
      if (!r.ok) throw new Error('Ollama unreachable');
      const data = await r.json();
      res.json({ models: (data.models || []).map(m => ({ id: m.name, name: m.name, provider: 'ollama', size: m.size })) });
    } catch (e) {
      res.json({ models: [], error: e.message });
    }
  } else {
    res.json({ models: [] });
  }
});

// ── Project Upload ────────────────────────────────────────────────────────────
app.post('/api/project/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) { res.status(400).json({ error: 'No file uploaded' }); return; }
    const TEXT_EXTS = ['.js','.ts','.tsx','.jsx','.py','.html','.css','.json',
      '.md','.txt','.sh','.yaml','.yml','.toml','.rs','.go',
      '.java','.cpp','.c','.h','.sql','.env','.gitignore'];
    let files = [];
    if (req.file.originalname.endsWith('.zip')) {
      const zip = new AdmZip(req.file.buffer);
      for (const e of zip.getEntries()) {
        if (!e.isDirectory) {
          const ext = path.extname(e.entryName).toLowerCase();
          const isText = TEXT_EXTS.includes(ext) || !ext;
          files.push({ name: e.entryName, content: isText ? e.getData().toString('utf8') : `[binary: ${ext}]`, type: isText ? 'text' : 'binary' });
        }
      }
    } else {
      files = [{ name: req.file.originalname, content: req.file.buffer.toString('utf8'), type: 'text' }];
    }
    res.json({ files });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Save File ─────────────────────────────────────────────────────────────────
app.post('/api/save-file', async (req, res) => {
  try {
    const { path: filePath, content } = req.body;
    if (!filePath) { res.status(400).json({ error: 'path required' }); return; }
    await fsp.writeFile(filePath, content, 'utf8');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Git API ───────────────────────────────────────────────────────────────────
const getGit = (repoPath) => {
  const p = repoPath || process.cwd();
  return simpleGit(fs.existsSync(p) ? p : process.cwd());
};

app.post('/api/git/status', async (req, res) => {
  try { res.json({ status: await getGit(req.body.repoPath).status() }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/git/diff', async (req, res) => {
  try {
    const git = getGit(req.body.repoPath);
    const diff = req.body.file ? await git.diff([req.body.file]) : await git.diff();
    res.json({ diff });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/git/commit', async (req, res) => {
  try {
    const git = getGit(req.body.repoPath);
    if (req.body.files?.length) await git.add(req.body.files);
    else await git.add('.');
    const result = await git.commit(req.body.message || 'WormGPT commit');
    res.json({ result });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/git/branch', async (req, res) => {
  try {
    await getGit(req.body.repoPath).checkoutLocalBranch(req.body.name);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Serve React Frontend ──────────────────────────────────────────────────────
const distPath = path.join(__dirname, '..', 'app', 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (_, res) => res.sendFile(path.join(distPath, 'index.html')));
} else {
  app.get('/', (_, res) => res.send(`
    <html><body style="background:#0a0a0a;color:#e94560;font-family:monospace;padding:40px">
    <h2>⚠ Frontend not built yet</h2>
    <p>Run: <code style="background:#111;padding:4px 8px">cd app && npm install && npm run build</code></p>
    </body></html>
  `));
}

// ── Graceful Shutdown ─────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;

const shutdown = (signal) => {
  console.log(`\n🛑 ${signal} received — shutting down...`);
  wss.clients.forEach(ws => { try { ws.close(); } catch {} });
  httpServer.close(() => { console.log('✅ Done.'); process.exit(0); });
  setTimeout(() => process.exit(1), 5000);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught:', err.message);
  if (err.code === 'EADDRINUSE') { console.error(`Port ${PORT} in use. Try: fuser -k ${PORT}/tcp`); process.exit(1); }
});
process.on('unhandledRejection', (r) => { console.error('⚠ Unhandled rejection:', r); });

// ── Start ─────────────────────────────────────────────────────────────────────
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🐛 WormGPT Android  →  http://localhost:${PORT}`);
  console.log(`📡 WebSocket        →  ws://localhost:${PORT}`);
  console.log(`🔧 Backend mode     →  ${backendMode}`);
  console.log(`📁 Frontend dist    →  ${fs.existsSync(distPath) ? distPath : '⚠ not built'}`);
  console.log(`\n   Password: Realnojokepplwazy1234`);
  console.log(`\n   Change backend via env vars:`);
  console.log(`   BACKEND_MODE=groq GROQ_API_KEY=gsk_xxx node index.js`);
  console.log(`   BACKEND_MODE=ollama OLLAMA_URL=http://192.168.1.10:11434 node index.js`);
  console.log(`   BACKEND_MODE=llamacpp LLAMACPP_URL=http://localhost:8080 node index.js\n`);
});
